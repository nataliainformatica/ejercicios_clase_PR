/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ut03e11bibliotecaspaquetes;

/**
 *
 * @author jar
 */
public class FuncionesSaludar {
    public static void SaludoNormal(){
        System.out.println("Hola");
    }
    
    public static void SaludoEnIngles(){
        System.out.println("Hello");
    }
    
    public static void SaludoPersonalizado(String nombre){
        System.out.println("Hola " + nombre);
    }
    
}
